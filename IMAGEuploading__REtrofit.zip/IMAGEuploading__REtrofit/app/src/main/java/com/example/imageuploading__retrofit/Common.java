package com.example.imageuploading__retrofit;

import android.content.ClipData;

public class Common {
    public static ITEM currentItem=null;
}
