package com.example.imageuploading__retrofit;

import android.view.View;

public interface RecyclerviewClickInterface {
    void onItemClicks(int position);
    void onLongItemClicks(int position);
}
