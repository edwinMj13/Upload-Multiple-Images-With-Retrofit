package com.example.imageuploading__retrofit;

public class ITEM {
    private String name;
    private boolean isChecked;

    public ITEM(String name) {
        this.name = name;
    }

    public ITEM(String name, boolean isChecked) {
        this.name = name;
        this.isChecked = isChecked;
    }

    public String getName() {
        return name;
    }

    public boolean isChecked() {
        return isChecked;
    }

    public void setName(String name) {
        this.name = name;
    }

    public void setChecked(boolean checked) {
        isChecked = checked;
    }
}
